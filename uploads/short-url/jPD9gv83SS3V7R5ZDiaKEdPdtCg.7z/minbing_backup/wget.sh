#!/bin/bash

wget wait=0.3 -k https://www.aisixiang.com/data/68296.html
wget wait=0.3 -k https://www.aisixiang.com/data/68296-2.html
wget wait=0.3 -k https://www.aisixiang.com/data/22380.html
for i in {2..5}
do
   wget wait=0.3 -k https://www.aisixiang.com/data/22380-$i.html
done
