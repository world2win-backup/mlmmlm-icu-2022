//****************************

//doubleads
 <!--
 var axel = Math.random();
 var ord = axel * 1000000000000000000;
 // This part of script alleviates a Netscape document.write bug
 NS4 = document.layers;
 if (NS4) {
 origWidth = innerWidth;
 origHeight = innerHeight;
 }
 function reDo() {
 if (innerWidth != origWidth || innerHeight != origHeight)
 location.reload();
 }
 if (NS4) onresize = reDo;

 var adrand=Math.round(axel*10);
 var langs = new Array('english','gb','big5');
 var asps = new Array('product.asp?id=', 'product.asp?id=','browse.asp?catid=','home.asp?');
 var lang = langs[adrand % 3];
 var asp = asps[adrand %4];
 var query;
 if(adrand%4 <= 1) {
    query = Math.round(axel*899+1)+'&';
 } else if(adrand%4 == 2) {
    var CC = new Array('A','B','C','D','E','G');
    var catid = Math.round(axel*13) % 5;
    if(catid == 0)
      query = CC[Math.round(axel*13)%6] +'&';
    else
      query = CC[Math.round(axel*13)%6] + catid+'&';
 } else {
    query = '';
 } 
 var ctrl=2; //1:yifan, 2:doubleclick
 var today = new Date();
 var tz = today.getTimezoneOffset()/60;
 var navn = navigator.appName;
 var adrand2 = Math.round(axel*100) % 6;
// if(navn != 'Netscape' && tz >= 4 && tz <= 8 && adrand2 <= 6)
// if(navn != 'Netscape' && (tz != -8 || adrand > 4))
 if(tz != -8 || adrand > 10)
    if(tz >= 4 && tz <= 9 && adrand > 8)
      ctrl = 3;
    else
      ctrl = 2;
 else
    ctrl = 1;
 var adscnt=0; 
 var yifancnt = 0;
 var idcount=43811;

 var initst = 0;
 var allowpopup = 0;
 var savind=-1;
 var initst = 0;
 var winpopup = null;
 var winpopup1 = null;
 var winpopup2 = null;
 var winpopup3 = null;
 var w51popup = null;
 allowpopup = 0;
 timeID=null;
 nnn=1;
 function shdesc(ind) {
  return false;
  if(ind == savind) return false;
  if(ind == 0) {
     xrand=Math.round(10*Math.random());
     ind = (xrand > 0)?xrand:1;
     if(ind > 9) ind=1;
  }

//  document.imgdesc.src = images[ind-1].src;
//  document.links[8].href = thepage[ind-1];
  document.imgdesc.src = images[0].src;
  document.links[8].href = thepage[0];
 if(timeID != null) clearTimeout(timeID);
 savind=ind;
 var indc=ind % 8 +1;
// setTimeout not needed for single case
// timeID=setTimeout('shdesc('+ indc + ')',10000);
  return false;
}  
function initializeimg() {
var doc=document;
doc.write('<table align="center" border=0 cellpadding=0 cellspacing=1>');
doc.write('<tr><td><table border=1 bgcolor="#E0EFFF" cellpadding=4 cellspacing=0 BORDERCOLORlight="#3E6299" bordercolordark="ffffff"><tr><td class=p9>');
doc.write('<a href="http://www.yifannet.com" onMouseOver="javascript:shdesc(1);">\u4ea6\u51e1\u4e3b\u9875</a></td></tr></table>');
doc.write('</td><td><table border=1 bgcolor="#E0EFFF" cellpadding=4 cellspacing=0 BORDERCOLORlight="#3E6299" bordercolordark="ffffff"><tr><td class=p9><a href="http://www.yifanmall.com" onMouseOver="javascript:shdesc(2);">\u4ea6\u51e1\u5546\u57ce</a></td></tr></table>');
doc.write('</td><td><table border=1 bgcolor="#E0EFFF" cellpadding=4 cellspacing=0 BORDERCOLORlight="#3E6299" bordercolordark="ffffff"><tr><td class=p9><a href="http://www.yifannet.com/xinwen" onMouseOver="javascript:shdesc(3);">\u65b0\u95fb\u4e2d\u5fc3</a></td></tr></table>');
doc.write('</td><td><table border=1 bgcolor="#E0EFFF" cellpadding=4 cellspacing=0 BORDERCOLORlight="#3E6299" bordercolordark="ffffff"><tr><td class=p9><a href="http://eo.yifan.net/" onMouseOver="javascript:shdesc(4);">\u5546\u52a1\u52a9\u7406</a></td></tr></table>');
doc.write('</td><td><table border=1 bgcolor="#E0EFFF" cellpadding=4 cellspacing=0 BORDERCOLORlight="#3E6299" bordercolordark="ffffff"><tr><td class=p9><a href="http://www.yifannet.com/liao/chat1.html" onMouseOver="javascript:shdesc(5);">\u804a\u5929\u5e7f\u573a</a></td></tr></table>');
doc.write('</td><td><table border=1 bgcolor="#E0EFFF" cellpadding=4 cellspacing=0 BORDERCOLORlight="#3E6299" bordercolordark="ffffff"><tr><td class=p9><a href="http://www.yifanbbs.com/" onMouseOver="javascript:shdesc(6);">\u56db\u6d77\u7eb5\u8c08</a></td></tr></table>');
doc.write('</td><td><table border=1 bgcolor="#E0EFFF" cellpadding=4 cellspacing=0 BORDERCOLORlight="#3E6299" bordercolordark="ffffff"><tr><td class=p9><a href="http://www.yifannet.com/postcard/" onMouseOver="javascript:shdesc(7);">\u8d3a\u5361\u5929\u5730</a></td></tr></table>');
doc.write('</td><td><table border=1 bgcolor="#E0EFFF" cellpadding=4 cellspacing=0 BORDERCOLORlight="#3E6299" bordercolordark="ffffff"><tr><td class=p9><a href="http://www.yifan.net/yihe/novels/cnovel.html" onMouseOver="javascript:shdesc(8);">\u4ea6\u51e1\u4e66\u5e93</a></td></tr></table>');
doc.write('</td></tr></table>');
doc.write('<center>');
initst = 1;  //used to place text
doubleads();
doc.write('</center>');
return false;
}
function tipanel() {
 var d = document;
 if(tz == -8) {
   d.writeln("<SCR"+"IPT language=javascript1.1 src='http://www.shuku.net/js/float_ti.js'></SCR"+"IPT>");
   return;
 } else {
 SPEC_AD('Middle'); return true;
 }
 var ind = Math.round(Math.random()*100) % 8 + 1;
 if(ind > 4) {
   document.writeln("<IFRAME ");
   document.writeln('SRC="http://ads.yifan.com:88/images/bs/bs480.html" ');
   document.writeln('WIDTH=480 HEIGHT=100 MARGINWIDTH=0 MARGINHEIGHT=0 HSPACE=0 VSPACE=0 FRAMEBORDER=0 SCROLLING=no bordercolor="#000000">');
   document.writeln('</IFRAME>');
 } else {
 d.writeln('<a href="http://bookstore.shuku.net/" target=_blank>');
 d.writeln('<img border=0 width=480 height=100 src="/bookstore/images/ads/banner'+ind+'_480.gif"></a>'); 
 }
  return false;
}
function cnads() {
  if(tz != -8 || Math.round(Math.random()*14) % 14 != 3) return true;
  document.writeln("<SCR"+"IPT language=javascript1.1 src='/js/china.js'></SCR"+"IPT>");
}

cnads();
// winsurvey = null;
// if(adrand < 2) popupsurvey();
function ReadCookie(cookieName) {
  var theCookie=""+document.cookie;
  var ind=theCookie.indexOf(cookieName);
  if (ind==-1 || cookieName=="") return "";
  var ind1=theCookie.indexOf(';',ind);
  if (ind1==-1) ind1=theCookie.length; 
  return unescape(theCookie.substring(ind+cookieName.length+1,ind1));
}
function popupsurvey() {
    if(ReadCookie('survey3') == 'yes') return;
    url="http://www.shuku.net/survey/";
    if((winsurvey == null) || (winsurvey.closed) ) {
      var features = "width=760,height=480,top=100,left=100,scrollbars=yes, location=0,toolbar=0,menubar=0,directories=0,status=0";           
      winsurvey = window.open(url,"popsurvey",features); 
    } else {
      winsurvey.location.replace(url);
    }
}
function doubleads(ind) {
  var spval = 0;
  if( doubleads.arguments.length <= 0) {
    adscnt++;
  } else if(ind == 8) {
    spval = 1;
  } else if(ind == 9 && ctrl == 2 && tz >=4 && tz <= 9) {
    spval= 2;  //3 always if entrance page
               //preserve ctrl for used in second ads 
  } else {
    adscnt++;
  }
  if(initst == 1 && ctrl == 3) ctrl = 2;//initst=1 only after iniimg,wheredoubleadscalled.
  if(ctrl ==1) {
    if(spval == 1) {
     dwsky();
     return true;
    }
    yifanads();
  } else if((ctrl == 3 && spval != 1) || spval == 2) {
    dwads();
  } else {
    var navn = navigator.appName;
    var adrand2 = Math.round(axel*100) % 6;
    if(spval == 0 && tz >= 4 && tz <= 8 && adrand2 <=6 && navn != 'Netscape') { 
         if(initst == 1) {
          // if( initst == 0 || adscnt != 2) d2clickads();
           if(adrand <= 8) { //7 prior 04/03/04
             if(adscnt != 2) d2clickads();
           } else if(adrand < 7) {
             dwads();
             if(Math.round(Math.random()*20) >= 16) popups();
           } else {
             fastclick();
           }
         } else {
           fastclick();
         }
    } else {
      //if(spval == 1 || adscnt > 0)yifancnt++;
      if(spval == 1) {
        fastsky();
      } else if (navn != 'Netscape') {
        //yifanads();
        fastclick();
      } else {
        dwads();
      }
    }
  }
}
function d2click(id) {
  if(d2click.arguments.length > 0) ord = id;
// MaxOnline JavaScript tag 
//var randomNum=Math.round(Math.random() * 100000000000);
  var dw=document.writeln;
if ((!document.images && navigator.userAgent.indexOf('Mozilla/2.') >= 0)
|| navigator.userAgent.indexOf("WebTV")>= 0) { 
dw('<A HREF="http://c4.maxserving.com/adclick/site=5978/area=ros/aamfmt=normal/aamsz=banner/PageID=' + ord + '" target="_blank">');
dw('<IMG SRC="http://c4.maxserving.com/iserver/site=5978/area=ros/aamfmt=normal/aamsz=banner/PageID=' + ord + '" border="0"></A>');
}else{
dw('<SCR'+'IPT src=http://c4.maxserving.com/gen.js?site=5978&area=ros&group=topbar&PageID=' + ord + '><\/SCR'+'IPT>');
}
}
function d2clickads() {
  return false;
  if(initst > 0 && adscnt == 1) {
   //buttonads();
 // if(Math.round(Math.random()*20) >= 16) popups();
 }
     document.writeln("<IFRAME ");
     document.writeln('SRC="/js/d2click.html" ');
     document.writeln('WIDTH=468 HEIGHT=60 MARGINWIDTH=0 MARGINHEIGHT=0 HSPACE=0 VSPACE=0 FRAMEBORDER=0 SCROLLING=no bordercolor="#000000">');
     document.writeln('</IFRAME>');
//Alternative to load d2click ads
//   d2click(ord);
 document.writeln('<img width=1 height=1 src="http://ads.yifan.com:88/d2c.gif?id=shuku&uniq='+ord+'&tz='+tz+'&qqnn">');
}
function fastclick() {
  if(adscnt > 1) {
    document.writeln('<!------------------->');
    return false;
  }
  if(initst > 0 && adscnt == 1) {
   buttonads();
 }
   SPEC_AD('Top'); return true;
   document.writeln("<IFRAME ");
   document.writeln('SRC="http://www.shuku.net/js/fastreg.html" ');
   document.writeln('WIDTH=468 HEIGHT=60 MARGINWIDTH=0 MARGINHEIGHT=0 HSPACE=0 VSPACE=0 FRAMEBORDER=0 SCROLLING=no bordercolor="#000000">');
   document.writeln('</IFRAME>');
}
function fastsky() {
//  if(tz >= 4 && tz <= 8 && adrand < 5) {
  if(tz >= 4 && tz <= 8) {
   if(Math.random()*10 >= 0) {
     dwsky();
   } else {
   dw=document.writeln;
   dw("<IFRAME ");
   dw('SRC="http://www.shuku.net/js/fastsky.html" ');
   dw('WIDTH=120 HEIGHT=600 MARGINWIDTH=0 MARGINHEIGHT=0 HSPACE=0 VSPACE=0 FRAMEBORDER=0 SCROLLING=no bordercolor="#000000">');
   dw('</IFRAME>');
   //dw('<img width=1 height=1 src="http://ads.yifan.com:88/fast.gif?id=shuku&uniq='+ord+'&tz='+tz+'&qqnn">'); 
  } 
  }else {
   return false;
  }
}
function dsads() {
   document.writeln("<a href='http://www.shuku.net/stores/dish/dishnetwork.html'>");
   document.writeln("<img src='http://ads.yifan.com:82/images/dw/dish-468.gif'  width=468 height=60 border=0>");
   document.writeln("</a>");
// document.writeln('<img border=0 width=0 height=0 src="http://ads.worldbizcity.com/cgi-bin/banner.cgi?mode=image&uname=yifan&rand='+ord+'">');
// document.writeln('<img width=1 height=1 src="http://ads.yifan.com:88/dw.gif?id=shuku&uniq='+ord+'&tz='+tz+'&qqnn">');
}
function pbads() {
   ind=Math.round(Math.random()*10) % 10 + 1;
   if(ind > 4) { 
   var ind2 = ind % 3 + 1;
   document.writeln("<IFRAME ");
   document.writeln('SRC="http://ads.yifan.com:88/images/bs/bs468-'+ind2+'.html" ');
   document.writeln('WIDTH=468 HEIGHT=60 MARGINWIDTH=0 MARGINHEIGHT=0 HSPACE=0 VSPACE=0 FRAMEBORDER=0 SCROLLING=no bordercolor="#000000">');
   document.writeln('</IFRAME>');
   } else {
   document.writeln("<a href='http://bookstore.shuku.net/' target=_blank>");
   document.writeln("<img src='/bookstore/images/ads/banner"+ind+"_468.gif'  width=468 height=60 border=0>");
   document.writeln("</a>");
   }
}
function buttonads() {
   SPEC_AD('Right'); return true;
   if(tz >= 4 && tz <= 8) {
   img126 = new Array('130','130','130');
   id126  = new Array('60387','60387','60387');
   ind = Math.round(axel*100) % id126.length;
     document.writeln("<a href='http://ads.yifan.com/cgi-bin/clickthru?id=scott&uic=jump2/?supbid="+id126[ind]+"'>");
   document.writeln("<img src='http://ads.yifan.com:88/images/dw/scott/chineserec"+img126[ind]+".gif"+"' width=120 height=60 border=0'>");
   document.writeln("</a>");
   } else {
   //document.writeln("<a href='http://www.yifanmall.com/gb/'><img src='http://www.shuku.net/images/malllogo.gif' border=0 height=58 alt=mall></a> ");
   }
}
function dwads() {
   return true;
   if(adscnt > 1 ) return false;
   if(tz != -8) {
      var adrand3 = Math.round(Math.random()*100) % 8;
   }
   SPEC_AD('Top'); return true;
   if(adrand3 < 0) {
     asiaff();
     return true;
   } else if(tz != -8 && adrand3 < 5) {
     pbads();
     return true;
   } 
   img468 = new Array('265','265');
   id468  = new Array('60390','60390');
   ind = Math.round(axel*100) % id468.length;
   var uic = ' ';
   if(ind == -1) uic='w8.asp'; else uic='jump2/';
     document.writeln("<a href='http://ads.yifan.com/cgi-bin/clickthru?id=scott&uic="+uic+"?supbid="+id468[ind]+"' target=_blank>");
   document.writeln("<img src='http://ads.yifan.com:88/images/dw/scott/chinesebnr"+img468[ind]+".gif?"+"' width=468 height=60 border=0'>");
   document.writeln("</a>");
}
function dwsky() {
   return true;
   SPEC_AD('Right1'); return true;
   img600 = new Array('221','221');
   id600  = new Array('60388','60388');
   ind = Math.round(axel*100) % id600.length;
   var uic = ' ';
   if(ind > 5) uic = 'w8.asp'; else uic = 'jump2/';
     document.writeln("<a href='http://ads.yifan.com/cgi-bin/clickthru?id=scott&uic="+uic+"?supbid="+id600[ind]+"'>");
   document.writeln("<img src='http://ads.yifan.com:88/images/dw/scott/chinesebar"+img600[ind]+".gif?"+"' width=120 height=600 border=0'>");
   document.writeln("</a>");
}
function popups() {     
  if(!allowpopup) return;
  if(tz < 4 || tz > 9) return false;
  var randpop=Math.round(Math.random()*10);
  if(randpop < 4) {
    img325 = new Array('cf544','cf563','cf564','cf565');
    ind = Math.round(axel*1000) % img325.length;
    dwindmx = 3; //divider of two different size windows
    var url = "http://ads.yifan.com/images/dw/scott/"+img325[ind]+"-300x250.htm";
    if(ind > dwindmx) {
      width=500;
      height=400;
      winpopup=winpopup2;
      winname='popupads2';
    } else {
      width=300;
      height=250;
      winpopup=winpopup1;
      winname='popupads';
    }
    var features = "width="+width+",height="+height+",top=10,left=60,scrollbars=no, location=0,toolbar=0,menubar=0,directories=0,status=0";           
    if((winpopup == null) || (winpopup.closed) ) {
      winpopup = window.open(url,winname,features); 
    } else {
      winpopup.location.replace(url);
    }
    if(ind > dwindmx)
      winpopup2=winpopup;
    else
      winpopup1=winpopup;
  } else {
    fastpop();
  }
}
function fastpop() {
  if(!allowpopup) return;
  if(adscnt > 1) {
    document.writeln('<!------------------->');
    return false;
  }
   document.writeln("<IFRAME ");
// document.writeln('SRC="http://www.yifanmall.com/'+lang+'/'+asp+query+'sess='+ord+'&ind=pop" ');
   document.writeln('SRC="/js/popupads.html" ');
   document.writeln('WIDTH=1 HEIGHT=1 MARGINWIDTH=0 MARGINHEIGHT=0 HSPACE=0 VSPACE=0 FRAMEBORDER=0 SCROLLING=no bordercolor="#000000">');
   document.writeln('</IFRAME>');
   document.writeln('<img width=1 height=1 src="http://ads.yifan.com:88/fast.gif?id=shuku&uniq='+ord+'&pop&tz='+tz+'&qqnn">'); 
}
function showads() {
  document.write("<!--------------No layer------->");
}
function mpanel(ind) {
  if(tz != -8) {
   SPEC_AD('Middle');
  } else {
   document.writeln('<scr'+'ipt src="/js/mpanel.js">');
   document.writeln('</scr'+'ipt>');
  }
}
function yifanads() {
if(adscnt > 1 || yifancnt > 0) { 
document.write("<!---------------------------------->\n");
} else {
//  SPEC_AD('Top'); return true;
  yifancnt++;
  var irand=Math.round(Math.random()*10);
  if( irand < 0) {
    asiaff();
  } else if(irand >= 0) {
    dwads();
  } else {
    zcnads();
  }
  return true;
var imgs = new Array ('bbs','zhengwen','sinoinfo','news','wangbao');
var hrefs = new Array ('www.yifanbbs.com','sousuo.shuku.net/cgi-bin/contest/vlist.pl',
             'www.sinoinfo.com','www.yifannet.com/xinwen/',
             'wangbao.shuku.net');
var vi=Math.round(axel*imgs.length) % imgs.length;
var img = "http://ads.yifan.com:82/images/ads-"+imgs[vi]+".gif";
var href = 'http://'+hrefs[vi];
var banner = '<a href="' + href +  '" target="_blank">';
banner += '<img src="' + img +  '" width=468 height=60 border=0></a>';
if(initst > 0) {
  buttonads();
}
document.write(banner);
 }
}
function zcnads() {
   if(initst > 0) {
     buttonads();
   }
   img468 = new Array('http://www.shuku.net/novels/pic/bixue.gif'); //extra element on img468 w/o pairwise on url for special features.
   url468  = new Array('http://www.bxonline.net/gg/yifan/index23.asp');
   ind = Math.round(Math.random()*10) % img468.length;
   var dw=document.writeln;
   if(ind < 0) {
     dw("<a href='"+url468[ind]+"' target=_blank>");
     dw("<img src='"+img468[ind]+"' width=468 height=60 border=0'>");
     dw("</a>");
   //dw('<scr'+'ipt language=JavaScript src="http://ad.999dy.com/ll/shuku.js"></scr'+'ipt>');
   } else {
     dw('<OBJECT classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=5,0,0,0" WIDTH=468 HEIGHT=60>');
     dw('<PARAM NAME=movie VALUE="http://www.shuku.net/novels/pic/xianlvqiyuan.swf"> <PARAM NAME=quality VALUE=high> <PARAM NAME=bgcolor VALUE=#FFFFFF> ');
     dw('</OBJECT>');
   }
}
function asiaff() {
  return true;
  var imgs = new Array ('asiaff~2','newer_asiaff02_gb','asiagb1','asiagb2','asiamt_gb',
             'find_gb','one_gb','true_gb','flip04a_b5','asiab5','asiamt_b5','find_b5_a',
             'one_b5_a','true_b5_a');
  var vi = Math.round(Math.random()*imgs.length) % imgs.length;
  var img = "http://banners.asiafriendfinder.com/banners/ffz/"+imgs[vi]+".gif";
  var href = "http://asiafriendfinder.com/go/f134216";
  var banner = '<a href="' + href +  '" target="_blank">';
  banner += '<img src="' + img +  '" width=468 height=60 border=0></a>';
  document.writeln(banner);
  if(initst == 9) { //disabled
  document.writeln("<br><center>");
  document.writeln('<a href="http://www.10168.com/?f=shuku.net" target=_blank>');
  document.writeln('<font color=red>��������-��Ůд��-Flash�ؿ�-�����Ӱ</font></a>');
  document.writeln('</center>');
  }
}
function SPEC_NORMAL(pos) { 
return;
}
//-->
SPEC_version = 11;
function SPEC_AD(pos) {
return;
}


// Place Google Analytics tracking all pages.
document.writeln('<scr' + 'ipt src="http://www.shuku.net/google-analytics.js" type="text/javascript"><\/scr' + 'ipt>');

